using System.Collections;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.Serialization;

public class Bullet : MonoBehaviour
{
    public float lifeTime;
    private float timePased;
    private float speed;

    public GameObject explode;
    public GameObject taill;

    public Players players;
    public string serchTag; 
    // Start is called before the first frame update
    void OnEnable()
    {
        taill.SetActive(true);
        explode.SetActive(false);
        timePased = 0;
    }

    // Update is called once per frame
    void Update()
    {
            if (timePased < lifeTime)
            {
                timePased += Time.deltaTime;
                this.gameObject.transform.position += new Vector3(speed, 0, 0) * Time.deltaTime;
            }
            else
            {
                StartCoroutine(Hit());
            }
    }

    public void SetSpeed(float speedSet)
    {
        speed = speedSet;
    }

    IEnumerator Hit()
    {
        taill.SetActive(false);
        explode.SetActive(true);
        yield return new WaitForSeconds(2f);
        gameObject.SetActive(false);
    }

    void OnCollisionEnter(Collision collision)
    {
        if ( collision.gameObject.CompareTag(serchTag))
        {
            Debug.Log(serchTag);
            players.Damage(serchTag);
        }
        else
        {
            Debug.Log(collision.gameObject.name);
        }
    }
}
