using System.Collections;
using System.Collections.Generic;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.Serialization;
using UnityEngine.UI;

public class GameUIManager : MonoBehaviour
{
    public GameObject startMenu;
    public List<TextMeshProUGUI> spetList;
   public GameObject victorry;
    public TextMeshProUGUI winer;
    public GameObject ui;

    public void StartMenuShow(int spepN)
    {
        startMenu.SetActive(true); 
        victorry.SetActive(false);
        ui.SetActive(false);
   
        for (int i = 0; i < spetList.Count; i++)
        {
            spetList[i].color = Color.red;
        }
        
        for (int i = 0; i < spepN; i++)
        {
            spetList[i].color = Color.green;
        }
    }

    public void VictorryShow(int PlayerWiner)
    {
        winer.text = "Player" + PlayerWiner + " WINS";
        victorry.SetActive(true);
        ui.SetActive(false);
        startMenu.SetActive(false);
        
    }

    public void Play()
    {
        ui.SetActive(true);
        victorry.SetActive(false);
        startMenu.SetActive(false);
    }

    public void playAgain()
    {
        SceneManager.LoadSceneAsync(1);
    }

    public void mainMenu()
    {
        SceneManager.LoadSceneAsync(0);
    }

    public void Quit()
    {
        Application.Quit();
        Debug.Log("EXIT");
    }
}
