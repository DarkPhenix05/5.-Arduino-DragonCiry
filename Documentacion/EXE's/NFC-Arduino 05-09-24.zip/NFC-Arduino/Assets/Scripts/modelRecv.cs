using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
public struct SCubeData
{
    public byte X;
    public byte Y;
    public byte Z;
    public byte C;
}

public struct SModel
{
    public string Name;
    public int CubeCount;
    public List<SCubeData> Cubes;
}

public class modelRecv : MonoBehaviour
{
    //[SerializeField] private UnityEngine.UI.Image indicaImage;
    [SerializeField] renderCubes drawCubesScr;

    private List<string> cubesRows = new List<string>();

    SModel modelin;
    private int numRows;

    private bool gotAModel;
    private bool isFirstBlk = true;

    public SerialController serialController;

    private int timesCalled;
    
    void Start()
    {
        timesCalled = 0;
        modelin = new SModel();
        modelin.Cubes = new List<SCubeData>();
    }

    void Update()
    {
        if(Input.GetKeyDown(KeyCode.P))
        {
            Debug.Log("Starting Read: \n");
            serialController.SendSerialMessage("A");
        }
    }
    // Invoked when a line of data is received from the serial device.
    public void OnMessageArrived(string msg)
    {
        if (timesCalled < 2)
        {
            Debug.Log(msg);

            if (msg.Contains("NFCREADY"))
            {
                Debug.Log("1");
                isFirstBlk = true;
            }

            else if (msg.Contains("NFCNONE"))
            {

            }
            else
            {
                if (isFirstBlk)
                {
                    ParseFirstBlock(msg);
                    isFirstBlk = false;
                }
                else
                {
                    if (!gotAModel)
                    {
                        cubesRows.Add(msg);

                        if (cubesRows.Count >= numRows)
                        {
                            gotAModel = true;
                        }
                    }
                }

                Debug.Log("RCV: " + msg);

                if (gotAModel)
                {
                    ParserCubesBlock(cubesRows);
                    drawCubesScr.SetModelToRender(modelin);

                    cubesRows.Clear();
                    Debug.Log("Got a model");

                    modelin.Cubes.Clear();
                    modelin.Name = "";
                    modelin.CubeCount = 0;
                    
                    Debug.Log("olyine");
                    timesCalled++;
                    gotAModel = false;
                }
            }
        }
        else
        {
            Debug.Log(msg);

            if (msg.Contains("NFCREADY"))
            {
                Debug.Log("1");
                isFirstBlk = true;
            }

            else if (msg.Contains("NFCNONE"))
            {

            }
            else
            {
                if (isFirstBlk)
                {
                    ParseFirstBlock(msg);
                    isFirstBlk = false;
                }
                else
                {
                    if (!gotAModel)
                    {
                        cubesRows.Add(msg);

                        if (cubesRows.Count >= numRows)
                        {
                            gotAModel = true;
                        }
                    }
                }

                Debug.Log("RCV: " + msg);

                if (gotAModel)
                {
                    ParserCubesBlock(cubesRows);
                    drawCubesScr.SetModelBullet(modelin);

                    cubesRows.Clear();
                    Debug.Log("Got a model");

                    modelin.Cubes.Clear();
                    modelin.Name = "";
                    modelin.CubeCount = 0;
                    
                    Debug.Log("olyine");
                    timesCalled++;
                    gotAModel = false;
                }
            }
        }
    }

        // Invoked when a connect/disconnect event occurs. The parameter 'success'
        // will be 'true' upon connection, and 'false' upon disconnection or
        // failure to connect.
    void OnConnectionEvent(bool success)
    {
        Debug.Log(success ? "Falcon Has Landed" : "Landing Failed");   
    }

    private void ParseFirstBlock(string blktxt)
    {
        byte[] nombre = new byte[8] 
        {
            0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20 
        };

        for (int i = 0; i < 16; i += 2)
        {
            if (blktxt[i] == '0') 
            { 
                continue; 
            }

            nombre[i / 2] = TwoCharToByte(blktxt[i], blktxt[i + 1]);
        }
        modelin.Name = Encoding.ASCII.GetString(nombre);
        modelin.CubeCount = FourCharToInt(blktxt[16], blktxt[17], blktxt[18], blktxt[19]);
        float fract = modelin.CubeCount / 8.0f;
        numRows = (int)(Math.Ceiling(fract));
    }

    private  void ParserCubesBlock(List<string> cubstxt)
    {
        int cubeCount = 0;
        for (int i = 0; i< cubstxt.Count; i++) 
        { 
            string roww = cubstxt[i];
            SCubeData cuboo = new SCubeData();
            for(int j = 0; j < 32; j += 4)
            {
                cuboo.X = charToByteConverter(roww[j]);
                cuboo.Y = charToByteConverter(roww[j+1]);
                cuboo.Z = charToByteConverter(roww[j+2]);
                cuboo.C = charToByteConverter(roww[j+3]);

                if(++cubeCount > modelin.CubeCount)
                {
                    break;
                }
                modelin.Cubes.Add(cuboo);
            }
        }
    }

    private byte TwoCharToByte(char hi, char lo)
    {
        int highByte = charToIntConverter(hi);
        int lowByte = charToIntConverter(lo);
        byte value = (byte)((highByte << 4) | lowByte);

        return value;
    }

    private int FourCharToInt(char hi1, char hi2, char lo1, char lo2)
    {
        int high1 = charToIntConverter(hi1);
        int high2 = charToIntConverter(hi2);
        int low1 = charToIntConverter(lo1);
        int low2 = charToIntConverter(lo2);

        int rhigh = ((high1 << 12) | (high2 << 8));
        int rlow = ((low1 << 4) | low2);

        int value = (rhigh | rlow);
        return value;
    }

    private byte charToByteConverter(char letra)
    {
        return (byte)charToIntConverter(letra);
    }

    private int charToIntConverter(char letra)
    {
        return "0123456789ABCDEF".IndexOf(char.ToUpper(letra));
    }
}