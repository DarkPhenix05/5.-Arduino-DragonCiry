using TMPro;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class Players : MonoBehaviour
{
    [SerializeField] renderCubes cubesScript;

    private List<sPersonaje> mPersonajes;
    private List<sPersonaje> mBullets;
    [SerializeField] List<Vector3> positions;
    [SerializeField] List<Quaternion> rotations;

    public float bulletSpeed;

    private Transform p1 = new RectTransform();
    private Transform p2 = new RectTransform();
    
    [Header("BULLET MODEL")]
    public GameObject bullet1;
    public GameObject bullet2;

    public float scale;
    
    [Header("SHOOT PARAMETERS")]
    public GameObject gun1;
    public GameObject gun2;

    [Header("BULLET PULL")]
    public GameObject bulletCont1;
    public GameObject bulletCont2;

    [SerializeField] List<GameObject> bullets1;
    [SerializeField] List<GameObject> bullets2;

    public List<int> health;
    public List<float> coolDown;
    public float wait;

    [SerializeField] TextMeshProUGUI p1Health; 
    [SerializeField] TextMeshProUGUI p2Health; 
    
    [SerializeField] TextMeshProUGUI p1CoolDown; 
    [SerializeField] TextMeshProUGUI p2CoolDown; 
    
    private int mCuantos;

    public float moveSpeed;

    public GameUIManager uIManager;
    public bool victorry;

    private void Start()
    {
        p1Health.text = "X " + health[0];
        p2Health.text = "X " + health[1];

        coolDown[0] = wait;
        coolDown[1] = wait;
        
        p1CoolDown.text = coolDown[0] + "s";
        p2CoolDown.text = coolDown[1] + "s";

    }

    void Update()
    {
        mPersonajes = cubesScript.GetCreatedPlayer();
        mBullets = cubesScript.GetCreatedBull();

        if (mPersonajes == null)
        {
            return;
        } 
        else if (mPersonajes.Count <= 2 && mBullets == null )
        {
            uIManager.StartMenuShow(mPersonajes.Count);
            return;
        }
        else if (mBullets.Count < 2)
        {
            uIManager.StartMenuShow(mPersonajes.Count + mBullets.Count);
            return;
        }
        else if(mBullets.Count + mPersonajes.Count == 4)
        {
            if(!victorry)
                uIManager.Play();
        }

        if (mPersonajes.Count > 0 && health[0] > 0)
        {
            if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.W))
            {
                if (p1.position.z < 17f)
                {
                    p1.position += new Vector3(0, 0, 1) * (moveSpeed * Time.deltaTime);
                }
            }

            if (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.S))
            {
                if (p1.position.z > -17f)
                {
                    p1.position -= new Vector3(0, 0, 1) * (moveSpeed * Time.deltaTime);
                }
            }

            if (Input.GetKeyDown(KeyCode.LeftShift) && coolDown[0] <= 0f)
            {
                coolDown[0] = wait;
                ShootP1();
            }
        }
        else if (health[0] <= 0)
        {
            uIManager.VictorryShow(2);
            victorry = true;
        }

        if (mPersonajes.Count > 1 && health[1] > 0)
        {
            if (Input.GetKey(KeyCode.UpArrow) || Input.GetKey(KeyCode.LeftArrow))
            {
                if (p2.position.z < 17f)
                {
                    p2.position += new Vector3(0, 0, 1) * (moveSpeed * Time.deltaTime);
                }
            }

            if (Input.GetKey(KeyCode.DownArrow) || Input.GetKey(KeyCode.RightArrow))
            {
                if (p2.position.z > -17f)
                {
                    p2.position -= new Vector3(0, 0, 1) * (moveSpeed * Time.deltaTime);
                }
            }

            if (Input.GetKeyDown(KeyCode.Keypad0) && coolDown[1] <= 0f)
            {
                ShootP2();
                coolDown[1] = wait;
            }
        }
        else if (health[1] <= 0)
        {
            uIManager.VictorryShow(1);
            victorry = true;
        }
        
        coolDown[0] -= Time.deltaTime;
        coolDown[1] -= Time.deltaTime;

        if (coolDown[0] <= 0)
        {
            p1CoolDown.text = "0s";
            p1CoolDown.text = "";
        }
        else
        {
            p1CoolDown.text = coolDown[0] + "s";
            p2CoolDown.text = "";
        }

        if (coolDown[1] <= 0)
        {
            p2CoolDown.text = "0s";
            p2CoolDown.text = "";
        }
        else
        {
            p2CoolDown.text = coolDown[1] + "s";
        }
    }

    public void BulletSetParent(int numb)
    {
        mBullets = cubesScript.GetCreatedBull();
        if (mBullets == null)
        {
            return;
        }

        if (numb > 0)
        {
            mBullets[0].mModel.transform.SetParent(bullet1.transform);
            mBullets[0].mModel.transform.position = bullet1.transform.position;
            mBullets[0].mModel.transform.localScale = scale * new Vector3(1f,1f,1f);
        }

        if (numb > 1)
        {
            mBullets[1].mModel.transform.SetParent(bullet2.transform);
            mBullets[1].mModel.transform.position = bullet2.transform.position;
            mBullets[1].mModel.transform.localScale = scale * new Vector3(1f,1f,1f);
        }
    }

    void ShootP1()
    {
        if (coolDown[0] < 0)
        {
            return;
        }

        gun1.transform.position = p1.position;
        
        foreach (var t in bullets1)
        {
            if (!t.activeInHierarchy)
            {
                t.transform.position = gun1.transform.position;
                t.SetActive(true);
                
                return;
            }
        }

        GameObject tempBull = Instantiate(bullet1, bulletCont1.transform);
        tempBull.transform.position = gun1.transform.position;
        tempBull.GetComponent<Bullet>().SetSpeed(-1 * bulletSpeed);
        tempBull.SetActive(true);
        bullets1.Add(tempBull);
    }

    void ShootP2()
    {
        gun2.transform.position = p2.position;
        
        foreach (var t in bullets2)
        {
            if (!t.activeInHierarchy)
            {
                t.transform.position = gun2.transform.position;
                t.SetActive(true);
              
                return;
            }
        }

        GameObject tempBull = Instantiate(bullet2,bulletCont2.transform);
        tempBull.transform.position = gun2.transform.position;
        tempBull.GetComponent<Bullet>().SetSpeed(1 * bulletSpeed);
        tempBull.SetActive(true);
        bullets2.Add(tempBull);
    }

    public void SetPos(int pnum, Transform trans)
    {
        if (pnum == 1)
        {
            trans.position = positions[0];
            trans.rotation = rotations[0];
            p1 = trans;
        }
        
        else if (pnum == 2)
        {
            trans.position = positions[1];
            trans.rotation = rotations[1];
            p2 = trans;
        }
    }

    public void Damage(string tagToDamage)
    {
        if (tagToDamage == "Player1")
        {
            health[0]--;
            
            p1Health.text = "X " + health[0].ToString();
            p2Health.text = "X " + health[1].ToString();
            
            Debug.Log("P1: " + health[0]);
        }
        else if (tagToDamage == "Player2")
        {
            health[1]--;
            
            p1Health.text = "X " + health[0].ToString();
            p2Health.text = "X " + health[1].ToString();
            
            Debug.Log("P2: " + health[1]);
        }
    }
}


