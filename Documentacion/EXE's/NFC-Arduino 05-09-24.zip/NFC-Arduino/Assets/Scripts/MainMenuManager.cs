using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenuManager : MonoBehaviour
{
    public GameObject mainMenu;
    public GameObject credits;
    public GameObject exit;

    public void MainMenuShow()
    {
        mainMenu.SetActive(true);
        credits.SetActive(false);
        exit.SetActive(false);
        Debug.Log("ShowMenu");
    }
    public void CreditsMenuShow()
    {
        credits.SetActive(true);
        exit.SetActive(false);
        mainMenu.SetActive(false);
        Debug.Log("ShowCred");
    }

    public void ExitMenuShow()
    {
        exit.SetActive(true);
        mainMenu.SetActive(false);
        credits.SetActive(false);
        Debug.Log("ShowExit");
    }

    public void Exit()
    {
        Debug.Log("EXIT");
        Application.Quit();
    }

    public void StartButton()
    {
        SceneManager.LoadSceneAsync(1);
    }
}
