using System.Collections.Generic;
using TMPro;
using UnityEngine;

public struct sPersonaje
{
	public GameObject mModel;
	public string mName;
}

public class renderCubes : MonoBehaviour
{
	[SerializeField] TextMeshProUGUI P1Display;
	[SerializeField] TextMeshProUGUI P2Display;
	
	[SerializeField] GameObject prefabBlock;

	private List<sPersonaje> mChar = new List<sPersonaje>();
	private List<sPersonaje> mBullets = new List<sPersonaje>();

	private Color[] paleta = new Color[] {
		new Color(0f, 0f, 0f),
		new Color(0.114f, 0.169f, 0.325f),
		new Color(0.494f, 0.145f, 0.325f),
		new Color(0, 0.529f, 0.318f),
		new Color(0.671f, 0.322f, 0.212f),
		new Color(0.373f, 0.341f, 0.31f),
		new Color(0.761f, 0.765f, 0.78f),
		new Color(1, 0.945f, 0.91f),
		new Color(1, 0, 0.302f),
		new Color(1, 0.639f, 0f),
		new Color(1, 0.925f, 0.153f),
		new Color(0, 0.894f, 0.212f),
		new Color(0.161f, 0.678f, 1f),
		new Color(0.514f, 0.463f, 0.612f),
		new Color(1f, 0.467f, 0.659f),
		new Color(1f, 0.8f, 0.667f),
	};

	public GameObject players;
	
	public List<sPersonaje> GetCreatedPlayer()
	{
		return mChar.Count > 0 ? mChar : null;
	}
	
	public List<sPersonaje> GetCreatedBull()
	{
		return mBullets.Count > 0 ? mBullets : null;
	}

	void Start()
	{
		P1Display.text = "-*-";
		P2Display.text = "-*-";
	}

	public void SetModelToRender(SModel cubes)
	{
		string namme = "Player" + (mChar.Count + 1);
		GameObject objToSpawn = new GameObject(namme);

		mChar.Add(new sPersonaje() { mModel = objToSpawn, mName = cubes.Name });

		for (int i = 0; i < cubes.CubeCount; i++)
		{
			SCubeData cbdta = cubes.Cubes[i];
			Vector3 cbpos = new Vector3(cbdta.X, cbdta.Z, -cbdta.Y);
			GameObject voxelcube = Instantiate(prefabBlock, cbpos, Quaternion.identity);
			voxelcube.GetComponent<MeshRenderer>().material.color = paleta[cbdta.C];
			voxelcube.transform.SetParent(objToSpawn.transform);
		}

		objToSpawn.AddComponent<BoxCollider>();
		objToSpawn.GetComponent<BoxCollider>().size = new Vector3(1f, 5.5f, 6f);
		objToSpawn.GetComponent<BoxCollider>().center = new Vector3(1f, 2f, -6.5f);
		
		players.GetComponent<Players>().SetPos(mChar.Count, objToSpawn.transform);
		Debug.Log(mChar.Count);

		if (mChar.Count == 1)
		{
			P1Display.text = cubes.Name;
		}
		else
		{
			P2Display.text = cubes.Name;
		}

		objToSpawn.tag = namme;
	}

	public void SetModelBullet(SModel cubes)
	{
		string namme = "Bullet" + (mBullets.Count + 1);
		GameObject objToSpawn = new GameObject(namme);

		mBullets.Add(new sPersonaje() { mModel = objToSpawn, mName = cubes.Name });

		for (int i = 0; i < cubes.CubeCount; i++)
		{
			SCubeData cbdta = cubes.Cubes[i];
			Vector3 cbpos = new Vector3(cbdta.X, cbdta.Z, -cbdta.Y);
			GameObject voxelcube = Instantiate(prefabBlock, cbpos, Quaternion.identity);
			voxelcube.GetComponent<MeshRenderer>().material.color = paleta[cbdta.C];
			voxelcube.transform.SetParent(objToSpawn.transform);
		}
		
		players.GetComponent<Players>().BulletSetParent(mBullets.Count);	
	}
	
	
}